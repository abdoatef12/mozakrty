const C='mozakrty-v5',F=['./','index.html','manifest.json','icon-192.png','icon-512.png','bg.mp4'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(F)));self.skipWaiting()});
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!=C).map(x=>caches.delete(x))))));
self.addEventListener('fetch',e=>{if(e.request.method!='GET')return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(n=>{const m=n.clone();caches.open(C).then(c=>c.put(e.request,m));return n}).catch(()=>caches.match('index.html'))))});
